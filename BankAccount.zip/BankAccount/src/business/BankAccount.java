package business;

public abstract class BankAccount {
    private String accountnm;
    private String firstnm;
    private String lastnm;
    private String owner;
    private double balance;

    public BankAccount(){
        accountnm="";
        firstnm="";
        lastnm="";
        owner="";
        balance=0;        
    }
    
    public BankAccount(int accountnm,String firstnm, String lastnm){
        
    }
    
    
    
    
    
    public String getAccountnm() {
        return accountnm;
    }

    public void setAccountnm(String accountnm) {
        this.accountnm = accountnm;
    }

    public String getFirstnm() {
        return firstnm;
    }

    public void setFirstnm(String firstnm) {
        this.firstnm = firstnm;
    }

    public String getLastnm() {
        return lastnm;
    }

    public void setLastnm(String lastnm) {
        this.lastnm = lastnm;
    }

    public abstract String getOwner();
    
    public abstract boolean WithdrawAmount(double w,String a);
    
    @Override
    public String toString()
    {
        
        return accountnm+" for "+firstnm+" "+lastnm;
    }

    public double getBalance() {
        
        return balance;
    }
}
