/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import javax.swing.JOptionPane;


public class Checking extends BankAccount {
//checking attributes
private String AccountType;
private double OverDraftFee;
private int NumberofOverdrafts;
private double WithdrawAmount;


    public Checking(){
        AccountType="";
        OverDraftFee=0;
        NumberofOverdrafts=0;
        WithdrawAmount=0;
    }
    
    public Checking(String account,String first,String last){
        super();
        WithdrawAmount=0;
    }

    public String getAccountType() {
        return AccountType;
    }

    public void setAccountType(String AccountType) {
        this.AccountType = AccountType;
    }

    public double getOverDraftFee() {
        return OverDraftFee;
    }

    public int getNumberofOverdrafts() {
        return NumberofOverdrafts;
    }

    public enum AccountType 
    {
    BASIC, PREMIERE 
    }
    
    @Override
    public String getOwner(){
        return "Checking Account #"+super.toString();
    }
    
@Override
    public boolean WithdrawAmount(double withdraw,String account){
        
        if(withdraw>super.getBalance()){
            
            OverDraftFee+=10;
            NumberofOverdrafts+=1;
            return true;
        }else{
            return false;
        }
    }
}
