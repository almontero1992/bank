
package business;

public class Savings extends BankAccount{
    
   
    private double Interest;
    
    
    public Savings(){
       
    }
    
     public Savings(String account,String first,String last){
        super();
        
    }
    
     public boolean AddInterest(){
         if(super.getBalance()>100){
             
             return true;
         }
         return false;
     }
    
    @Override
    public String getOwner(){
        return "Savings Account #"+super.toString();
    }
    
    @Override
    public boolean WithdrawAmount(double withdraw,String account){
        return false;
    }
}
